"""Collects every number quoted in the revised manuscript into results/paper_numbers.json."""
import json, numpy as np, pandas as pd, os
R = "results"
J = lambda f: json.load(open(os.path.join(R, f)))
cal = J("calibration.json"); main = J("main_test.json"); sec = J("secondary_stress.json")
orig = J("original_design.json"); w = J("weights.json")
grid = pd.read_csv(os.path.join(R, "grid.csv")); stab = pd.read_csv(os.path.join(R, "stability.csv"))
N = {}
f = lambda v: float(np.nanmean(np.array(v, float)))
sd = lambda v: float(np.nanstd(np.array(v, float)))
N["cal"] = {"kappa": cal["kappa"], "ap_by_kappa": cal["ap_by_kappa"], "thr": cal["thresholds"],
            "n_acc": cal["n_cal_accounts"], "n_att": cal["n_cal_attackers"]}
N["main"] = {"nets": len(main), "n_mean": f([r["n"] for r in main]), "att_total": sum(r["attackers"] for r in main),
             "att_mean": f([r["attackers"] for r in main]), "prev": f([r["attackers"] / r["n"] for r in main]),
             "pairs_mean": f([r["pairs"] for r in main]), "pairs_sd": sd([r["pairs"] for r in main]),
             "cset_mean": f([r["c_set"] for r in main]), "cset_frac": f([r["c_set"] / r["n"] for r in main]),
             "screen_recall_min": float(min(r["screen_recall"] for r in main)),
             "reduction": f([1 - r["pairs"] / (r["n"] * (r["n"] - 1) / 2) for r in main]),
             "units_mean": f([r["methods"]["CSS (full)"]["n_units"] for r in main])}
meth = {}
for m in main[0]["methods"]:
    d = {}
    for k in ["ap", "roc_auc", "roc_auc_cset", "pair_auc", "via", "high_precision", "high_recall", "high_fp_per_10k",
              "queue_per_1k", "queue_precision", "reported_or_queued_recall", "missed"]:
        v = [r["methods"][m].get(k, np.nan) for r in main]
        d[k] = [f(v), sd(v)]
    meth[m] = d
N["methods"] = meth
c = [r["methods"]["CSS (full)"] for r in main]
N["boot"] = {k: [f([x[k] for x in c]), sd([x[k] for x in c])] for k in ["boot_auc_lo", "boot_auc_hi", "boot_ap_lo", "boot_ap_hi", "boot_frac_perfect"]}
N["boot"]["across_ap_p2.5"] = float(np.percentile([x["ap"] for x in c], 2.5))
N["boot"]["across_ap_p97.5"] = float(np.percentile([x["ap"] for x in c], 97.5))
N["boot"]["across_ap_min"] = float(min(x["ap"] for x in c)); N["boot"]["across_ap_max"] = float(max(x["ap"] for x in c))
N["roles"] = {ro: {k: int(sum(r["roles"][ro][k] for r in main)) for k in ["n", "high", "medium"]} for ro in main[0]["roles"]}
N["dormant"] = {"n": sum(r["dormant"]["n"] for r in main),
                **{o: {k: int(sum(r["dormant"][o][k] for r in main)) for k in main[0]["dormant"][o]} for o in ["name_time", "creation"]}}
N["burst"] = {k: int(sum(r["burst"][k] for r in main)) for k in main[0]["burst"]}
# replay
rep = {}
tot_n = sum(r["n"] for r in main)
for cp in main[0]["replay"]:
    a = {k: int(sum(r["replay"][cp][k] for r in main)) for k in main[0]["replay"][cp]}
    a["att_flag_rate"] = a["att_flag"] / a["att_eval"]; a["att_high_rate"] = a["att_high"] / a["att_eval"]
    a["ben_flag_per_10k"] = a["ben_flag"] / tot_n * 1e4
    rep[cp] = a
N["replay"] = rep
ff = [v for r in main for v in r["first_flag"].values()]
fv = np.array([v for v in ff if v is not None]) / 24
N["replay_delay"] = {"never": int(sum(v is None for v in ff)), "n": len(ff), "median_days": float(np.median(fv)),
                     "p75_days": float(np.percentile(fv, 75)), "p90_days": float(np.percentile(fv, 90)),
                     "by_48h": float(np.mean([v is not None and v <= 48 for v in ff])),
                     "by_7d": float(np.mean([v is not None and v <= 168 for v in ff])),
                     "by_30d": float(np.mean([v is not None and v <= 720 for v in ff]))}
# attackers by speed
at = pd.DataFrame([a for r in main for a in r["methods"]["CSS (full)"]["attackers"]])
at["speed"] = at.detail.str.extract(r"speed=(\w+)", expand=False)
at["pert"] = at.detail.str.extract(r"pert=(\w+)", expand=False)
N["by_speed"] = {s: {"n": int(len(g)), "queued_or_reported": float((g.band != "LOW").mean()), "via": float(g.victim_ok.mean()),
                     "mean_score": float(g.score.mean())} for s, g in at.groupby("speed")}
N["by_pert"] = {s: {"n": int(len(g)), "queued_or_reported": float((g.band != "LOW").mean())} for s, g in at.groupby("pert")}
# pair types / signals
sg = pd.DataFrame([s for r in main for s in r["sig"]], columns=["type", "J", "S1", "S2", "S3", "S4", "S5", "S6", "S7"])
N["signals_by_type"] = sg.groupby("type").mean().round(3).to_dict(orient="index")
N["pairs_by_type"] = sg.groupby("type").size().to_dict()
pt = pd.DataFrame([t for r in main for t in r["methods"]["CSS (full)"]["pair_types"]], columns=["type", "css"])
N["css_by_type"] = pt.groupby("type").css.agg(["mean", "std", "min", "max", "size"]).round(3).to_dict(orient="index")
N["s2_eq_s6_frac"] = float((np.isclose(sg.S2, sg.S6)).mean())
# secondary stress
sr = {ro: {k: int(sum(r["roles"][ro][k] for r in sec)) for k in ["n", "high", "medium"]} for ro in sec[0]["roles"]}
N["secondary_stress"] = {"nets": len(sec), "roles": sr,
                         "queue_precision": [f([r["methods"]["CSS (full)"]["queue_precision"] for r in sec]), sd([r["methods"]["CSS (full)"]["queue_precision"] for r in sec])],
                         "queue_per_1k": f([r["methods"]["CSS (full)"]["queue_per_1k"] for r in sec]),
                         "ap": f([r["methods"]["CSS (full)"]["ap"] for r in sec])}
# grid
cols = {"CSS (full)": "full", "CSS static terms (J, S1, S2, S7)": "static", "CSS temporal terms (S3-S6)": "temporal", "Name similarity only": "name"}
gt = grid.groupby(["burst", "speed", "o"])[list(cols)].mean().rename(columns=cols).round(3)
N["grid"] = {f"{b}|{s}|{o}": row.to_dict() for (b, s, o), row in gt.iterrows()}
N["grid_seeds"] = int(grid.seed.nunique())
# original design
N["original"] = {m: {k: [f([r[m][k] for r in orig]), float(np.nanmin([r[m][k] for r in orig]))] for k in orig[0][m]}
                 for m in orig[0] if m not in ("seed", "n", "pairs")}
N["original"]["pairs_mean"] = f([r["pairs"] for r in orig])
N["original"]["ap_perfect_nets"] = int(sum(r["CSS (full)"]["ap"] >= 1 - 1e-9 for r in orig))
N["original"]["pair_auc_perfect_nets"] = int(sum(r["CSS (full)"]["pair_auc"] >= 1 - 1e-9 for r in orig))
# stability
N["stability"] = stab.round(4).to_dict(orient="records")
# weights
ap = np.array(w["mean_ap"]); vv = np.array(w["mean_via"]); W = np.array(w["weights"][1:])
N["weights"] = {"equal_ap": float(ap[0]), "equal_via": float(vv[0]), "n": len(ap) - 1, "median_ap": float(np.median(ap[1:])),
                "p5_ap": float(np.percentile(ap[1:], 5)), "p95_ap": float(np.percentile(ap[1:], 95)),
                "frac_ge_equal": float((ap[1:] >= ap[0]).mean()), "max_ap": float(ap[1:].max()),
                "median_via": float(np.median(vv[1:])), "p5_via": float(np.percentile(vv[1:], 5)),
                "corr": {nm: float(np.corrcoef(W[:, i], ap[1:])[0, 1]) for i, nm in enumerate(["J", "S1", "S2", "S3", "S4", "S5", "S6", "S7"])},
                "suspect_only_share_low": float(W[ap[1:] < np.percentile(ap[1:], 10)][:, [0, 1, 3, 4]].sum(1).mean()),
                "suspect_only_share_rest": float(W[ap[1:] >= np.percentile(ap[1:], 10)][:, [0, 1, 3, 4]].sum(1).mean())}
if os.path.exists(os.path.join(R, "runtime.csv")):
    N["runtime"] = pd.read_csv(os.path.join(R, "runtime.csv")).to_dict(orient="records")
if os.path.exists(os.path.join(R, "runtime_env.json")):
    N["runtime_env"] = J("runtime_env.json")
json.dump(N, open(os.path.join(R, "paper_numbers.json"), "w"), indent=1, default=float)
print(json.dumps({k: N[k] for k in ["main", "boot", "roles", "dormant", "burst", "replay_delay", "by_speed", "by_pert", "secondary_stress", "s2_eq_s6_frac", "css_by_type"]}, indent=0, default=float)[:6000])
