# Two-pillar clone detector — code, data generator and evaluation

Companion artifact (code, generator, data and results) for the revised manuscript *"A Two-Pillar, Training-Free Explainable Detector for Profile
Cloning on Follower-Based Social Platforms"* (IJIES, manuscript 20267372).

Everything in the paper's Section 6 is produced by the scripts below from fixed random seeds. No real user
data is used: all networks are synthetic and can be regenerated exactly.


> **Download note.** To stay under GitHub's 25 MB upload limit, the release is split into two archives:
> `clonedet_v1_part1_code_results.zip` (code, results, calibration and original-design networks) and
> `clonedet_v1_part2_test_data.zip` (the 30 test networks). Unzip both into the same folder; together they
> recreate the `clonedet/` folder described below. All files are stored exactly (no rounding).

## Contents

| Path | What it is |
|---|---|
| `clonedet/generator.py` | Seeded generator of directed temporal follow networks with injected clones, renamed dormant attackers, legitimate namesakes, authorised secondary accounts and onboarding bursts (Section 5.1, Table 5). Name pool rules are in the same file. |
| `clonedet/detector.py` | The detector: NFKC + case-fold bigram screening (exhaustive and exact indexed versions), signals S1–S7 with the conventions of Section 4.4, the Clone Suspicion Score, and the baseline scores. |
| `clonedet/evaluate.py` | Labels, account scores, threshold calibration, metrics, cluster bootstrap over candidate-graph components, chronological replay. |
| `run_experiments.py` | All experiments: `calibration`, `main`, `secondary`, `grid`, `stability`, `original`, `weights`. |
| `bench_runtime.py` | Runtime and memory benchmark (Table 11). |
| `paper_numbers.py` | Collects every number quoted in the paper into `results/paper_numbers.json`. |
| `make_figures.py` | Fig. 2 (and a runtime plot). |
| `export_dataset.py` | Writes the released networks to `data/`. |
| `verify_dataset.py` | Checks every released network against a fresh regeneration, edge validity, label consistency, and recomputes the per-pair signals and Table 9 from the CSV files alone. |
| `cumulative_counts.py` | Section 6.4: endpoint snapshot versus cumulative rule for every account; writes `results/cumulative_counts.json`. |
| `tests/test_detector.py` | Hand-checkable unit tests of the signal conventions and of indexed = exhaustive screening. |
| `data/` | Calibration (seeds 1–10), test (101–130) and original-design (401–430) networks. Each folder has `profiles.csv`, `edges.csv`, `labels.csv`, `params.json`; test folders also have `pair_signals.csv` (per-pair signals, CSS and label). |
| `results/` | Raw outputs of every experiment. |

### Data format
* `profiles.csv`: `id, t0, name, name_time, community, onboarding` — times are hours since 2010-01-01 00:00 UTC; `name_time` is the reference time t_ref (time the current name was adopted).
* `edges.csv`: `src, dst, t` — `src` follows `dst` at time `t` (full floating-point precision; rounding can move an edge across the 48 h burst window or a 30-day bucket boundary). No unfollows are generated; the detector also accepts an optional `t_end` column.
* `labels.csv`: `id, role, target, detail` — `role` ∈ {ordinary, victim, clone, dormant_attacker, namesake, secondary, owner}; `target` is the victim (or owner) id; `detail` records the attack or benign parameters drawn for that account.
* `pair_signals.csv`: `A, B, label, J_name, S1…S7, CSS` with `label` 1 = attacker–own-victim pair, 0 = other, −1 = two attackers of the same victim (excluded).

## Reproduce

```bash
pip install -r requirements.txt
python tests/test_detector.py
python run_experiments.py            # all stages, about 10 minutes on 2 cores
python bench_runtime.py              # runtime table
python paper_numbers.py && python make_figures.py
python cumulative_counts.py         # endpoint vs cumulative counts (Section 6.4)
python verify_dataset.py            # integrity check of the released data
python export_dataset.py
```

Seeds: calibration 1–10; test 101–130; controlled grid 201–208; stability calibration 301–305 and test 311–318;
original design 401–430; random weightings seed 7.

## Frozen settings (from calibration networks only)
λ = 0.60 (analytical); κ = 32 for the S5 shrinkage; τ_H = 0.795 and τ_M = 0.365; equal weights 0.125.

## Where each result comes from

| Paper item | Stage / script | Output |
|---|---|---|
| κ, τ_H, τ_M (Table 6) | `run_experiments.py calibration` | `results/calibration.json` |
| Section 6.1, Table 7 | `run_experiments.py main`, then `paper_numbers.py` | `results/main_test.json` → `paper_numbers.json` (`main`, `methods`) |
| Table 3 (worked example) | `export_dataset.py` | `data/test/seed_101/pair_signals.csv` |
| Fig. 2, Section 6.3 | `run_experiments.py grid`, `make_figures.py` | `results/grid.csv`, `figures/fig2_temporal_value.png` |
| Table 8 (point-in-time replay) | `run_experiments.py main` | `paper_numbers.json` (`replay`, `replay_delay`) |
| Section 6.4, endpoint vs cumulative counts | `cumulative_counts.py` | `results/cumulative_counts.json` |
| Data integrity (all 70 networks) | `verify_dataset.py` | `results/dataset_check.json` |
| Table 9, Section 6.5 | `run_experiments.py main` (roles, dormant, burst) and `secondary` | `paper_numbers.json` (`roles`, `dormant`, `burst`, `secondary_stress`) |
| Table 10 | `run_experiments.py stability` | `results/stability.csv` |
| Section 6.6 (weights, bootstrap, original design) | `run_experiments.py weights`, `original`; bootstrap inside `main` | `results/weights.json`, `results/original_design.json` |
| Table 11 | `bench_runtime.py` | `results/runtime.csv`, `results/runtime_env.json` |

### Counting rules
Tables 7, 9 and 10 use the **endpoint snapshot**: each pair is scored once on the graph at the end of observation
(31 May 2026). Table 8 gives **point-in-time** counts at each replay offset. Section 6.4 also reports the
**cumulative** rule of Section 4.5 (highest band reached at any checkpoint or at the endpoint), produced by
`cumulative_counts.py`.

## Citation and licence
Please cite the article (see `CITATION.cff`). Archived version: Zenodo DOI [10.5281/zenodo.XXXXXXX]. Licence: see `LICENSE`.
