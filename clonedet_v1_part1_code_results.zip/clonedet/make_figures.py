import json, os, numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif"], "font.size": 10,
                     "axes.linewidth": 0.6, "savefig.dpi": 300})
R = "results"; os.makedirs("figures", exist_ok=True)
g = pd.read_csv(os.path.join(R, "grid.csv"))
cols = {"CSS (full)": ("Full CSS", "#1f3b73", "o"), "CSS static terms (J, S1, S2, S7)": ("Static terms only", "#c0504d", "s"),
        "CSS temporal terms (S3-S6)": ("Temporal terms only", "#4f9a55", "^")}
fig, axes = plt.subplots(1, 2, figsize=(5.8, 2.55), sharey=True)
for ax, b, title in zip(axes, [0, 1], ["(a) Namesakes follow gradually", "(b) Namesakes follow in a first-hour burst"]):
    for m, (lab, colr, mk) in cols.items():
        for sp, ls in [("48h", "-"), ("90d", "--")]:
            d = g[(g.burst == b) & (g.speed == sp)].groupby("o")[m].agg(["mean", "std"])
            ax.plot(d.index, d["mean"], ls=ls, color=colr, marker=mk, ms=3.5, lw=1.1,
                    label=f"{lab}, clone copies in {'48 h' if sp == '48h' else '90 days'}")
    ax.set_title(title, fontsize=10)
    ax.set_xlabel("Namesake's shared-interest overlap o")
    ax.set_xticks([0, 0.2, 0.4, 0.6, 0.8]); ax.grid(alpha=0.25, lw=0.5)
axes[0].set_ylabel("Pair-level ROC-AUC")
axes[0].set_ylim(0.80, 1.0)
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=2, fontsize=8, frameon=False, bbox_to_anchor=(0.5, -0.02))
fig.tight_layout(rect=(0, 0.2, 1, 1))
fig.savefig("figures/fig2_temporal_value.png")
print("fig2 ok")

if os.path.exists(os.path.join(R, "runtime.csv")):
    rt = pd.read_csv(os.path.join(R, "runtime.csv"))
    fig, ax = plt.subplots(figsize=(3.17, 2.4))
    names = {0.0: "low", 0.5: "medium", 0.8: "high"}
    colors = {0.0: "#4f9a55", 0.5: "#1f3b73", 0.8: "#c0504d"}
    for z, d in rt.groupby("zipf"):
        ax.loglog(d.n, d.screen_indexed_s, "-o", color=colors[z], ms=3, lw=1, label=f"Indexed, {names[z]} collisions")
        e = d.dropna(subset=["screen_exhaustive_s"])
        ax.loglog(e.n, e.screen_exhaustive_s, ":s", color=colors[z], ms=3, lw=1, label=f"Exhaustive, {names[z]}")
    ax.set_xlabel("Profiles n"); ax.set_ylabel("Screening time (s)")
    ax.grid(alpha=0.25, which="both", lw=0.4); ax.legend(fontsize=7, frameon=False)
    fig.tight_layout(); fig.savefig("figures/fig3_runtime.png"); print("fig3 ok")
