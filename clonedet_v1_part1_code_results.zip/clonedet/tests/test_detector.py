"""Hand-checkable tests of the signal definitions and screening exactness."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np
import pandas as pd
from clonedet import detector as D
from clonedet.generator import generate, config

H = 1.0; DAY = 24.0


def make(edges, n):
    return D.TemporalGraph(n, pd.DataFrame(edges, columns=["src", "dst", "t"]))


def test_jaccard_examples():
    # doubled character in a name of l distinct bigrams gives (l-1)/l (Section 4.3)
    a, b = D.bigrams("abcdefghij"), D.bigrams("abcdefghijj")
    assert abs(D.jaccard(a, b) - 9 / 10) < 1e-12
    assert D.jaccard(frozenset(), frozenset()) == 0.0
    # NFKC + casefold: full-width letters equal ASCII
    assert D.bigrams("ＡＢＣ") == D.bigrams("abc")


def test_signals_full_copy():
    # A=0 victim created at 0 follows 2,3,4 over months; followers 5,6 follow A early.
    # B=1 created at 1000 copies 2,3,4 within 2 h; follower 5 then follows B.
    tref = np.array([0.0, 1000.0, 0, 0, 0, 0, 0])
    E = [(0, 2, 10), (0, 3, 500), (0, 4, 900), (5, 0, 20), (6, 0, 30),
         (1, 2, 1000.5), (1, 3, 1001), (1, 4, 1002), (5, 1, 1100)]
    G = make(E, 7)
    s = D.signals(G, 0, 1, 1.0, tref, T=1000 + 400 * DAY, kappa=0.0)
    J, S1, S2, S3, S4, S5, S6, S7 = s
    assert S7 == 1.0 and S3 == 1.0 and S5 == 1.0
    assert S2 == 1.0            # |{5}| / min(2, 1)
    assert S6 == 1.0            # follower 5 followed A before B existed
    # r(A) = 2/3, r(B) = 1/3, rho = 1 -> S1 = 0.5
    assert abs(S1 - 0.5) < 1e-12
    # 13 complete 30-day buckets, one follower in bucket 0 -> CV = sqrt(12), S4 = CV/(1+CV)
    cv = np.sqrt(12.0)
    assert abs(S4 - cv / (1 + cv)) < 1e-9


def test_zero_denominators_and_time_cut():
    tref = np.array([0.0, 100.0, 0.0])
    G = make([(0, 2, 5)], 3)
    s = D.signals(G, 0, 1, 0.7, tref, T=200.0)
    assert np.all(s[1:] == 0.0) and s[0] == 0.7
    # an edge created after T is invisible
    G = make([(1, 2, 300.0)], 3)
    assert D.signals(G, 0, 1, 0.7, tref, T=200.0)[3] == 0.0


def test_s5_shrinkage():
    tref = np.array([0.0, 1000.0, 0, 0])
    G = make([(0, 2, 1), (1, 2, 1001)], 4)
    assert D.signals(G, 0, 1, 1, tref, 2000, kappa=0)[5] == 1.0
    assert abs(D.signals(G, 0, 1, 1, tref, 2000, kappa=3)[5] - 0.25) < 1e-12


def test_unfollow_convention():
    E = pd.DataFrame([(0, 1, 10.0, 50.0), (0, 1, 80.0, np.nan)], columns=["src", "dst", "t", "t_end"])
    G = D.TemporalGraph(2, E)
    assert G.out_at(0, 40) == {1: 10.0}
    assert G.out_at(0, 60) == {}
    assert G.out_at(0, 90) == {1: 80.0}


def test_indexed_equals_exhaustive():
    for z in (0.0, 0.5, 0.8):
        p, e, l = generate(config("base", n_ordinary=800, name_zipf=z), 3)
        tr = p.name_time.to_numpy()
        assert D.screen_indexed(p.name.tolist(), tr) == D.screen_exhaustive(p.name.tolist(), tr)


if __name__ == "__main__":
    for k, f in list(globals().items()):
        if k.startswith("test_"):
            f(); print("ok", k)
