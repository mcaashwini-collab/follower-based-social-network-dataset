"""Writes the released dataset: calibration (1-10), test (101-130) and original-design (401-430)
networks, plus per-pair signals and labels of the test networks.  Output: data/"""
import os, sys, json
import pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from clonedet.generator import generate, config
from clonedet.evaluate import NetworkEval

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
KAPPA = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results/calibration.json")))["kappa"]
splits = {"calibration": ("base", range(1, 11)), "test": ("base", range(101, 131)),
          "original_design": ("original_design", range(401, 431))}
for split, (cfg, seeds) in splits.items():
    for s in seeds:
        d = os.path.join(OUT, split, f"seed_{s:03d}")
        os.makedirs(d, exist_ok=True)
        prm = config(cfg)
        prof, edges, lab = generate(prm, s)
        prof.to_csv(os.path.join(d, "profiles.csv"), index=False)
        edges.to_csv(os.path.join(d, "edges.csv"), index=False)  # full precision: rounding moves edges across the 48 h and bucket boundaries
        lab.to_csv(os.path.join(d, "labels.csv"), index=False)
        json.dump({"config": cfg, "seed": s, "params": prm.to_dict()}, open(os.path.join(d, "params.json"), "w"), indent=1, default=str)
        if split == "test":
            ne = NetworkEval(None, s, kappa=KAPPA, data=(prof, edges, lab))
            rows = [{"A": A, "B": B, "label": int(l), "J_name": sg[0], "S1": sg[1], "S2": sg[2], "S3": sg[3], "S4": sg[4],
                     "S5": sg[5], "S6": sg[6], "S7": sg[7], "CSS": float(sg.mean())}
                    for (A, B), l, sg in zip(ne.pair_keys, ne.pair_label, ne.sig)]
            pd.DataFrame(rows).to_csv(os.path.join(d, "pair_signals.csv"), index=False, float_format="%.6f")
print("done")
