"""Two-pillar clone detector (revised version).

Conventions (Section 4.4 of the revised manuscript):
* A pair (A, B) is ordered by the reference time t_ref of each profile, i.e. the
  time at which the profile adopted its current display name (= creation time
  t0 for a profile that was never renamed); ties are broken by identifier.
  ordering="creation" reproduces the original submission (t_ref = t0).
* Signals are computed on the graph as observed at time T: only edges with
  t <= T are used.  The generator simulates no unfollows; if an edge table
  carries a column t_end, edges with t_end <= T are dropped (a re-follow is a
  new row, and its own t is used).
* Every ratio whose denominator is zero is set to 0 (no evidence).
* S4 uses complete 30-day buckets from t_ref(B) to T; the trailing partial
  bucket is discarded; fewer than two complete buckets, or no follower gained
  after t_ref(B), gives S4 = 0; sigma is the population standard deviation.
* S5 is shrunk towards 0 when few accounts are shared:
  S5 = conc * |C| / (|C| + kappa), kappa fixed on calibration networks.
"""
from __future__ import annotations

import math
import unicodedata
from collections import defaultdict

import numpy as np

H48 = 48.0
D1 = 24.0
BUCKET = 30 * 24.0
LAMBDA = 0.60


def normalise(name: str) -> str:
    return unicodedata.normalize("NFKC", name).casefold()


def bigrams(name: str) -> frozenset:
    s = normalise(name)
    return frozenset(s[i:i + 2] for i in range(len(s) - 1))


def jaccard(a: frozenset, b: frozenset) -> float:
    if not a and not b:
        return 0.0
    i = len(a & b)
    return i / (len(a) + len(b) - i)


# --------------------------------------------------------------------------
# Pillar 1: screening
# --------------------------------------------------------------------------
def processing_order(t_ref, ids):
    return sorted(ids, key=lambda v: (t_ref[v], v))


def screen_exhaustive(names, t_ref, lam=LAMBDA):
    """Algorithm 1: compare every profile with every earlier profile."""
    ids = processing_order(t_ref, range(len(names)))
    bg = [bigrams(n) for n in names]
    pairs = {}
    seen = []
    for v in ids:
        bv = bg[v]
        for u in seen:
            j = jaccard(bg[u], bv)
            if j >= lam:
                pairs[(u, v)] = j
        seen.append(v)
    return pairs


def screen_indexed(names, t_ref, lam=LAMBDA):
    """Exact Jaccard similarity join: prefix filter + size filter + verification.

    Returns exactly the pairs of screen_exhaustive (checked empirically)."""
    ids = processing_order(t_ref, range(len(names)))
    bg = [bigrams(n) for n in names]
    freq = defaultdict(int)
    for b in bg:
        for g in b:
            freq[g] += 1
    rank = {g: (f, g) for g, f in freq.items()}          # global order: rare first
    sorted_bg = [sorted(b, key=rank.__getitem__) for b in bg]
    index = defaultdict(list)                           # bigram -> earlier profiles (prefix only)
    pairs = {}
    for v in ids:
        sv = sorted_bg[v]
        nv = len(sv)
        if nv == 0:
            continue
        pref = nv - math.ceil(lam * nv) + 1
        cand = set()
        for g in sv[:pref]:
            for u in index[g]:
                nu = len(bg[u])
                if lam * nv <= nu <= nv / lam:
                    cand.add(u)
        bv = bg[v]
        for u in cand:
            j = jaccard(bg[u], bv)
            if j >= lam:
                pairs[(u, v)] = j
        for g in sv[:pref]:
            index[g].append(v)
    return pairs


# --------------------------------------------------------------------------
# Time-aware graph
# --------------------------------------------------------------------------
class TemporalGraph:
    """Follow graph with edge creation times.

    Optional column t_end (removal time, NaN if never removed): an edge counts
    at time T iff t <= T and (t_end is NaN or t_end > T).  A re-follow after an
    unfollow must be supplied as a new row; the latest row of a pair whose
    creation time is <= T is the one used, so its own creation time applies."""

    def __init__(self, n, edges):
        self.n = n
        self.hist_out = [dict() for _ in range(n)]   # v -> {w: [(t, t_end), ...]}
        self.hist_in = [dict() for _ in range(n)]
        has_end = "t_end" in edges.columns
        ends = edges["t_end"].to_numpy(float) if has_end else np.full(len(edges), np.nan)
        for (u, v, t), te in zip(edges[["src", "dst", "t"]].itertuples(index=False), ends):
            u, v = int(u), int(v)
            self.hist_out[u].setdefault(v, []).append((float(t), te))
            self.hist_in[v].setdefault(u, []).append((float(t), te))
        self.simple = not has_end
        if self.simple:
            self.out = [{w: h[0][0] for w, h in d.items()} for d in self.hist_out]
            self.inn = [{u: h[0][0] for u, h in d.items()} for d in self.hist_in]

    @staticmethod
    def _active(hist, T):
        best = None
        for t, te in hist:
            if t <= T and (best is None or t > best[0]):
                best = (t, te)
        if best is None or (not math.isnan(best[1]) and best[1] <= T):
            return None
        return best[0]

    def _view(self, simple_d, hist_d, T):
        if self.simple:
            return {w: t for w, t in simple_d.items() if t <= T}
        out = {}
        for w, h in hist_d.items():
            t = self._active(h, T)
            if t is not None:
                out[w] = t
        return out

    def out_at(self, v, T):
        return self._view(self.out[v] if self.simple else None, self.hist_out[v], T)

    def in_at(self, v, T):
        return self._view(self.inn[v] if self.simple else None, self.hist_in[v], T)


# --------------------------------------------------------------------------
# Pillar 2: signals
# --------------------------------------------------------------------------
SIGNALS = ["J", "S1", "S2", "S3", "S4", "S5", "S6", "S7"]


def signals(G: TemporalGraph, A, B, jname, t_ref, T, kappa=0.0):
    outA, outB = G.out_at(A, T), G.out_at(B, T)
    inA, inB = G.in_at(A, T), G.in_at(B, T)
    dA_out, dB_out, dA_in, dB_in = len(outA), len(outB), len(inA), len(inB)
    tB = t_ref[B]
    # S1 degree-ratio gap
    rA = dA_in / max(dA_out, 1)
    rB = dB_in / max(dB_out, 1)
    rho = (min(dA_out, dB_out) / max(dA_out, dB_out)) if max(dA_out, dB_out) > 0 else 0.0
    s1 = rho * max(0.0, 1 - rB / rA) if rA > 0 else 0.0
    # S2 common followers
    common_in = inA.keys() & inB.keys()
    m = min(dA_in, dB_in)
    s2 = len(common_in) / m if m > 0 else 0.0
    # S3 out-edge burst
    s3 = (sum(1 for t in outB.values() if tB <= t <= tB + H48) / dB_out) if dB_out > 0 else 0.0
    # S4 follower-growth irregularity
    W = int((T - tB) // BUCKET)
    s4 = 0.0
    if W >= 2:
        g = np.zeros(W)
        for t in inB.values():
            if t >= tB:
                i = int((t - tB) // BUCKET)
                if i < W:
                    g[i] += 1
        mu = g.mean()
        if mu > 0:
            cv = g.std() / mu
            s4 = cv / (1 + cv)
    # S5 timestamp concentration
    C = outA.keys() & outB.keys()
    s5 = 0.0
    if C:
        ts = sorted(outB[w] for w in C)
        best, j = 0, 0
        for i in range(len(ts)):
            while ts[i] - ts[j] > D1:
                j += 1
            best = max(best, i - j + 1)
        s5 = (best / len(C)) * (len(C) / (len(C) + kappa))
    # S6 stolen followers
    s6 = (sum(1 for u in inB if u in inA and inA[u] < tB) / dB_in) if dB_in > 0 else 0.0
    # S7 following-list Jaccard
    union = len(outA.keys() | outB.keys())
    s7 = len(C) / union if union > 0 else 0.0
    return np.array([jname, s1, s2, s3, s4, s5, s6, s7])


EQUAL_W = np.full(8, 1 / 8)


def css(sig, w=EQUAL_W):
    return float(np.dot(sig, w))


# --------------------------------------------------------------------------
# Baselines (all computed on the same candidate pairs)
# --------------------------------------------------------------------------
def neighbourhood_score(G, A, B, jname, T):
    """Adaptation of the Clone Security System [1] to follow edges: name
    similarity times the share of B's neighbours that lie in A's 1-hop
    neighbourhood (followers and followees of A, plus A)."""
    NA = set(G.out_at(A, T)) | set(G.in_at(A, T)) | {A}
    NB = set(G.out_at(B, T)) | set(G.in_at(B, T))
    return jname * (len(NB & NA) / len(NB)) if NB else 0.0


def containment_score(G, A, B, jname, T):
    """Jin et al.-style attribute plus friend-list similarity, adapted to
    follows: mean of name similarity and the share of B's followees that A
    also follows."""
    oA, oB = G.out_at(A, T), G.out_at(B, T)
    c = len(oA.keys() & oB.keys()) / len(oB) if oB else 0.0
    return 0.5 * jname + 0.5 * c


def burst_score_account(G, v, t_ref, T):
    d = G.out_at(v, T)
    if not d:
        return 0.0
    return sum(1 for t in d.values() if t_ref[v] <= t <= t_ref[v] + H48) / len(d)


SUBSETS = {
    "CSS (full)": [0, 1, 2, 3, 4, 5, 6, 7],
    "CSS static terms (J, S1, S2, S7)": [0, 1, 2, 7],
    "CSS temporal terms (S3-S6)": [3, 4, 5, 6],
    "Static overlap rule (J, S2, S7)": [0, 2, 7],
    "Name similarity only": [0],
}
