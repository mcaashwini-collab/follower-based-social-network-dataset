"""Synthetic directed temporal follow-network generator with injected attacks.

Every network is fully determined by (params, seed).  Time is measured in hours
from 2010-01-01 00:00 UTC.  The generator writes three tables:

profiles : id, t0 (creation time), name, name_time (time the current display
           name was adopted; equals t0 unless the account was renamed),
           community, onboarding (bool)
edges    : src, dst, t  (src follows dst at time t; no unfollows are simulated)
labels   : id, role, target, detail
           role in {ordinary, victim, clone, dormant_attacker, namesake,
                    secondary, owner}
           target = victim id (clone, dormant_attacker, namesake) or owner id
           (secondary); -1 otherwise.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field, asdict

import numpy as np
import pandas as pd

HOUR = 1.0
DAY = 24.0
YEAR = 365.25 * DAY
T_END = (pd.Timestamp("2026-05-31") - pd.Timestamp("2010-01-01")).total_seconds() / 3600.0


def to_date(t: float) -> pd.Timestamp:
    return pd.Timestamp("2010-01-01") + pd.Timedelta(hours=float(t))


def year_to_t(y: float) -> float:
    return (y - 2010.0) * YEAR


# --------------------------------------------------------------------------
# Name pool: syllable-built names, so that no real person's name is used.
# --------------------------------------------------------------------------
_ONSETS = ["b", "d", "g", "k", "l", "m", "n", "p", "r", "s", "t", "v", "w", "z",
           "f", "sh", "ch", "h", "j", "y", "dh", "bh", "th", "pr", "sr", "kr", "gr",
           "tr", "br", "dr", "st", "sm", "sn", "kl", "pl", "gl", "fl", "x", "q"]
_VOWELS = ["a", "e", "i", "o", "u", "aa", "ee", "ai", "ou", "y", "ei", "oo"]


def _make_tokens(rng, n_tokens, min_syl, max_syl):
    out, seen = [], set()
    while len(out) < n_tokens:
        k = rng.integers(min_syl, max_syl + 1)
        s = "".join(rng.choice(_ONSETS) + rng.choice(_VOWELS) for _ in range(k))
        if rng.random() < 0.35:
            s += rng.choice(["n", "r", "l", "sh", "m", "t", "k", "x", "z", "ck", "ng", "nd"])
        s = s.capitalize()
        if s not in seen and len(s) >= 3:
            seen.add(s)
            out.append(s)
    return out


_POOL_RNG = np.random.default_rng(20260101)
FIRST_NAMES = _make_tokens(_POOL_RNG, 400, 2, 3)
LAST_NAMES = _make_tokens(_POOL_RNG, 600, 2, 4)

HOMOGLYPHS = {"a": "а", "e": "е", "o": "о", "c": "с", "p": "р"}


def zipf_probs(n, s):
    w = 1.0 / np.arange(1, n + 1) ** s
    return w / w.sum()


def perturb(name: str, kind: str, rng) -> str:
    """Apply one attacker edit of the given kind to a 'First Last' name."""
    first, last = name.split(" ", 1)
    if kind == "exact":
        return name
    if kind == "double":
        w = last if rng.random() < 0.5 else first
        i = int(rng.integers(1, len(w)))
        w2 = w[:i] + w[i - 1] + w[i:]
        return f"{first} {w2}" if w is last else f"{w2} {last}"
    if kind == "delete":
        w = last if rng.random() < 0.5 else first
        if len(w) <= 3:
            return name[:-1]
        i = int(rng.integers(1, len(w) - 1))
        w2 = w[:i] + w[i + 1:]
        return f"{first} {w2}" if w is last else f"{w2} {last}"
    if kind == "insert":
        w = last
        i = int(rng.integers(1, len(w)))
        c = rng.choice(list("aeiourn"))
        return f"{first} {w[:i] + c + w[i:]}"
    if kind == "trailing":
        return name + rng.choice([".", "_"])
    if kind == "separator":
        return f"{first}{rng.choice(['.', '_'])}{last}"
    if kind == "homoglyph":
        idx = [i for i, ch in enumerate(name) if ch.lower() in HOMOGLYPHS]
        if not idx:
            return name + "."
        i = int(rng.choice(idx))
        return name[:i] + HOMOGLYPHS[name[i].lower()] + name[i + 1:]
    raise ValueError(kind)


# --------------------------------------------------------------------------
@dataclass
class GenParams:
    n_ordinary: int = 3000
    mean_out: float = 15.0          # mean organic out-degree of an ordinary user
    n_communities: int = 30
    p_community: float = 0.7        # share of follows aimed inside own community
    name_zipf: float = 0.5          # name-collision level (0 = low, 0.5 = medium, 0.8 = high)
    onboarding_frac: float = 0.30   # ordinary users who follow suggested accounts in first hour
    onboarding_k: tuple = (10, 30)
    # attacks
    n_victims: int = 20
    clones_per_victim: tuple = (1, 2)
    copy_frac: tuple = (0.4, 1.0)
    copy_speed: dict = field(default_factory=lambda: {"48h": 0.5, "2w": 0.3, "90d": 0.2})
    camouflage: tuple = (0.0, 0.3)
    p_deceive: tuple = (0.2, 0.6)
    perturbations: dict = field(default_factory=lambda: {
        "exact": 0.10, "double": 0.20, "delete": 0.15, "insert": 0.10,
        "trailing": 0.15, "separator": 0.20, "homoglyph": 0.10})
    n_dormant: int = 3              # renamed dormant accounts used as clones
    # benign look-alikes
    namesakes_per_victim: int = 1
    namesake_overlap: tuple = (0.0, 0.6)    # share of namesake follows drawn from victim's list
    namesake_burst_frac: float = 0.3        # namesakes that build their list in a first-hour burst
    n_secondary: int = 5                    # authorised secondary accounts
    # special settings for the design of the original submission
    victim_min_degree: int = 8
    victim_boost: bool = False
    original_design: bool = False

    def to_dict(self):
        return asdict(self)


def _sample_weighted(rng, cum, ids, k):
    """Sample up to k distinct ids with probability proportional to weights (cum = cumsum)."""
    if len(ids) == 0 or k <= 0:
        return np.array([], dtype=int)
    k = min(k, len(ids))
    picks = set()
    tries = 0
    total = cum[-1]
    while len(picks) < k and tries < 6 * k + 20:
        r = rng.random(k) * total
        for j in np.searchsorted(cum, r, side="right"):
            picks.add(int(ids[min(j, len(ids) - 1)]))
            if len(picks) >= k:
                break
        tries += k
    return np.fromiter(picks, dtype=int)


class _Net:
    def __init__(self):
        self.t0, self.name, self.name_time, self.comm, self.onb = [], [], [], [], []
        self.edges = {}          # (u, v) -> t
        self.outl, self.inl = {}, {}   # adjacency: v -> {w: t}
        self.role, self.target, self.detail = [], [], []

    def add(self, t0, name, comm, onb=False, role="ordinary", target=-1, detail=""):
        self.t0.append(t0); self.name.append(name); self.name_time.append(t0)
        self.comm.append(comm); self.onb.append(onb)
        self.role.append(role); self.target.append(target); self.detail.append(detail)
        return len(self.t0) - 1

    def follow(self, u, v, t):
        if u == v or t > T_END:
            return False
        if (u, v) in self.edges:
            return False
        if t < self.t0[u] or t < self.t0[v]:
            return False
        self.edges[(u, v)] = float(t)
        self.outl.setdefault(u, {})[v] = float(t)
        self.inl.setdefault(v, {})[u] = float(t)
        return True

    def out_at(self, v, t):
        return [w for w, tt in self.outl.get(v, {}).items() if tt <= t]

    def in_at(self, v, t):
        return [u for u, tt in self.inl.get(v, {}).items() if tt <= t]


def generate(params: GenParams, seed: int):
    rng = np.random.default_rng(seed)
    P = params
    net = _Net()
    fn_p = zipf_probs(len(FIRST_NAMES), P.name_zipf)
    ln_p = zipf_probs(len(LAST_NAMES), P.name_zipf)

    def new_name():
        return f"{FIRST_NAMES[rng.choice(len(FIRST_NAMES), p=fn_p)]} {LAST_NAMES[rng.choice(len(LAST_NAMES), p=ln_p)]}"

    # ---- ordinary users -------------------------------------------------
    span = T_END - 30 * DAY
    for _ in range(P.n_ordinary):
        t0 = span * rng.random() ** 0.6
        net.add(t0, new_name(), int(rng.integers(P.n_communities)),
                onb=bool(rng.random() < P.onboarding_frac))
    n0 = len(net.t0)
    t0 = np.array(net.t0)
    comm = np.array(net.comm)
    pop = rng.pareto(1.3, n0) + 1.0                     # popularity weight
    order = np.argsort(t0)

    comm_ids = {c: np.where(comm == c)[0] for c in range(P.n_communities)}
    comm_cum = {c: np.cumsum(pop[ids]) for c, ids in comm_ids.items()}
    all_ids = np.arange(n0)
    all_cum = np.cumsum(pop)
    top_popular = np.argsort(-pop)[: max(50, n0 // 30)]

    def organic_out(v, k, scale_days=None, start=None, exclude=()):
        """v follows k targets organically over time."""
        start = net.t0[v] if start is None else start
        scale = (scale_days if scale_days is not None else rng.uniform(30, 720)) * DAY
        kc = int(rng.binomial(k, P.p_community))
        tg = list(_sample_weighted(rng, comm_cum[net.comm[v]], comm_ids[net.comm[v]], kc))
        tg += list(_sample_weighted(rng, all_cum, all_ids, k - kc))
        made = 0
        for w in tg:
            if w in exclude:
                continue
            base = max(start, net.t0[w])
            if net.follow(v, w, base + rng.exponential(scale)):
                made += 1
        return made

    if P.original_design:
        # very sparse background, as in the original submission (mean degree ~1.75)
        for v in range(n0):
            k = int(rng.poisson(0.9))
            organic_out(v, k)
    else:
        for v in range(n0):
            k = max(1, int(rng.lognormal(math.log(P.mean_out) - 0.32, 0.8)))
            k = min(k, n0 // 4)
            if net.onb[v]:
                ko = int(rng.integers(*P.onboarding_k))
                for w in rng.choice(top_popular, size=min(ko, len(top_popular)), replace=False):
                    net.follow(v, int(w), max(net.t0[v], net.t0[w]) + rng.uniform(0, 1) * HOUR)
                k = max(1, k - ko // 2)
            organic_out(v, k)

    # degree snapshot helpers
    in_at = net.in_at

    # ---- victims ---------------------------------------------------------
    out_deg = np.zeros(n0, int); in_deg = np.zeros(n0, int)
    for (u, w) in net.edges:
        out_deg[u] += 1; in_deg[w] += 1
    lo, hi = year_to_t(2012), year_to_t(2020)
    if P.original_design:
        lo, hi = year_to_t(2016), year_to_t(2020)
    eligible = [v for v in range(n0) if lo <= net.t0[v] <= hi and
                (P.victim_boost or (in_deg[v] >= P.victim_min_degree and out_deg[v] >= P.victim_min_degree))]
    victims = list(rng.choice(eligible, size=min(P.n_victims, len(eligible)), replace=False))
    for v in victims:
        net.role[v] = "victim"
        if P.victim_boost:   # give victims 14-20 followers and 15-20 follows, built organically
            k_out = int(rng.integers(15, 21)) - out_deg[v]
            if k_out > 0:
                organic_out(v, int(k_out), scale_days=rng.uniform(60, 400))
            k_in = int(rng.integers(14, 21)) - in_deg[v]
            cands = rng.choice(n0, size=max(0, int(k_in)) * 3, replace=False)
            got = 0
            for u in cands:
                if got >= k_in:
                    break
                if net.follow(int(u), v, max(net.t0[u], net.t0[v]) + rng.exponential(200 * DAY)):
                    got += 1

    used_dormant = set()

    def run_copy_attack(c, v, tc, order_idx):
        """Account c (created or renamed at tc) copies victim v and harvests its followers."""
        if P.original_design:
            frac = 1.0 if order_idx == 0 else rng.uniform(0.35, 0.55)
            speed = "48h"
            camo = 0.0
            pdec = rng.uniform(0.35, 0.6) if order_idx == 0 else 0.3
        else:
            frac = rng.uniform(*P.copy_frac)
            speed = rng.choice(list(P.copy_speed), p=np.array(list(P.copy_speed.values())))
            camo = rng.uniform(*P.camouflage)
            pdec = rng.uniform(*P.p_deceive)
        window = {"48h": 48 * HOUR, "2w": 14 * DAY, "90d": 90 * DAY}[speed]
        src = net.out_at(v, tc)
        ncopy = max(1, int(round(frac * len(src))))
        copied = list(rng.choice(src, size=min(ncopy, len(src)), replace=False)) if src else []
        for w in copied:
            net.follow(c, int(w), tc + rng.uniform(0, window))
        for w in rng.choice(top_popular, size=int(round(camo * len(copied))), replace=False):
            net.follow(c, int(w), tc + rng.uniform(0, window))
        for u in in_at(v, tc):
            if rng.random() < pdec:
                net.follow(u, c, tc + rng.exponential(15 * DAY))
        for _ in range(int(rng.poisson(0.7))):
            u = int(rng.integers(n0))
            net.follow(u, c, tc + rng.uniform(0, 120 * DAY))
        return f"copy={frac:.2f};speed={speed};camo={camo:.2f};pdec={pdec:.2f}"

    pert_kinds = list(P.perturbations)
    pert_p = np.array(list(P.perturbations.values())); pert_p /= pert_p.sum()
    for v in victims:
        if P.original_design:
            n_c = 2
        else:
            n_c = int(rng.integers(P.clones_per_victim[0], P.clones_per_victim[1] + 1))
        tcs = []
        for j in range(n_c):
            if P.original_design:
                tc = year_to_t(2024.7) + rng.uniform(0, 1.2) * YEAR if j == 0 else year_to_t(2025.0) + rng.uniform(0, 1.35) * YEAR
                kind = rng.choice(["exact", "double", "delete"], p=[0.1, 0.6, 0.3]) if j == 0 else rng.choice(["trailing", "separator"], p=[0.35, 0.65])
            else:
                tc = rng.uniform(max(net.t0[v] + YEAR, year_to_t(2018)), T_END - 45 * DAY)
                kind = rng.choice(pert_kinds, p=pert_p)
            tc = min(tc, T_END - 20 * DAY)
            c = net.add(tc, perturb(net.name[v], kind, rng), net.comm[v], role="clone", target=v)
            det = run_copy_attack(c, v, tc, j)
            net.detail[c] = f"order={j + 1};pert={kind};{det}"
            tcs.append(tc)

    # ---- renamed dormant accounts used as clones (R2.4) -----------------
    if P.n_dormant and not P.original_design:
        dormant_pool = [u for u in range(n0) if net.role[u] == "ordinary" and net.t0[u] < year_to_t(2016)
                        and out_deg[u] <= 2 and in_deg[u] <= 2]
        targets = list(rng.choice(victims, size=min(P.n_dormant, len(victims)), replace=False))
        for v in targets:
            if not dormant_pool:
                break
            a = int(dormant_pool.pop(int(rng.integers(len(dormant_pool)))))
            ta = rng.uniform(max(net.t0[v] + YEAR, year_to_t(2019)), T_END - 45 * DAY)
            kind = rng.choice(pert_kinds, p=pert_p)
            net.name[a] = perturb(net.name[v], kind, rng)
            net.name_time[a] = ta
            net.role[a] = "dormant_attacker"; net.target[a] = v
            net.detail[a] = f"pert={kind};" + run_copy_attack(a, v, ta, 0)

    # ---- namesakes (legitimate users who share a victim's name) ----------
    for v in victims:
        for _ in range(P.namesakes_per_victim):
            if P.original_design:
                tn = year_to_t(2019.95) + rng.uniform(0, 2.2) * YEAR
                o, burst = 0.0, False
            else:
                tn = rng.uniform(year_to_t(2010.5), T_END - 200 * DAY)
                o = rng.uniform(*P.namesake_overlap)
                burst = bool(rng.random() < P.namesake_burst_frac)
            nm = net.name[v] if rng.random() < 0.55 else perturb(net.name[v], rng.choice(["double", "delete", "insert"]), rng)
            s = net.add(tn, nm, net.comm[v], role="namesake", target=v, detail=f"overlap={o:.2f};burst={burst}")
            k = max(5, int(rng.lognormal(math.log(P.mean_out) - 0.32, 0.6))) if not P.original_design else int(rng.integers(13, 17))
            src = [w for w in net.outl.get(v, {}) if w != s]
            k_shared = min(len(src), int(round(o * k)))
            shared = list(rng.choice(src, size=k_shared, replace=False)) if k_shared else []
            for w in shared:
                base = max(tn, net.t0[w])
                t = base + (rng.uniform(0, 1) * HOUR if burst else rng.exponential(rng.uniform(60, 900) * DAY))
                net.follow(s, int(w), t)
            if burst:
                for w in rng.choice(top_popular, size=min(k - k_shared, len(top_popular)), replace=False):
                    net.follow(s, int(w), max(tn, net.t0[w]) + rng.uniform(0, 1) * HOUR)
            else:
                organic_out(s, k - k_shared, exclude=set(shared))
            # followers: organic, plus members of the shared community
            n_f = int(rng.integers(13, 17)) if P.original_design else max(2, int(rng.lognormal(math.log(P.mean_out) - 0.5, 0.7)))
            got = 0
            for u in rng.choice(n0, size=n_f * 3, replace=False):
                if got >= n_f:
                    break
                if net.follow(int(u), s, max(tn, net.t0[u]) + rng.exponential(300 * DAY)):
                    got += 1
            for u in list(net.inl.get(v, {})):
                if rng.random() < 0.3 * o:
                    net.follow(u, s, max(tn, net.t0[u]) + rng.exponential(300 * DAY))

    # ---- authorised secondary accounts (R2.4) ----------------------------
    if P.n_secondary and not P.original_design:
        owners_pool = [u for u in range(n0) if net.role[u] == "ordinary" and in_deg[u] >= 5 and out_deg[u] >= 5
                       and net.t0[u] < T_END - 2 * YEAR]
        for o_ in rng.choice(owners_pool, size=min(P.n_secondary, len(owners_pool)), replace=False):
            o_ = int(o_)
            ts = rng.uniform(net.t0[o_] + YEAR, T_END - 60 * DAY)
            first, last = net.name[o_].split(" ", 1)
            nm = rng.choice([net.name[o_], f"{first} {last} 2", f"{first}.{last}", f"{first} {last} Official"])
            s = net.add(ts, str(nm), net.comm[o_], role="secondary", target=o_)
            net.role[o_] = "owner" if net.role[o_] == "ordinary" else net.role[o_]
            frac = rng.uniform(0.5, 1.0)
            window = 48 * HOUR if rng.random() < 0.5 else 30 * DAY
            src = net.out_at(o_, ts)
            for w in rng.choice(src, size=max(1, int(frac * len(src))), replace=False) if src else []:
                net.follow(s, int(w), ts + rng.uniform(0, window))
            if rng.random() < 0.9:
                net.follow(s, o_, ts + rng.uniform(0, 1) * HOUR)
            if rng.random() < 0.8:
                net.follow(o_, s, ts + rng.uniform(0, 3) * DAY)
            pf = rng.uniform(0.1, 0.4)
            for u in in_at(o_, ts):
                if rng.random() < pf:
                    net.follow(u, s, ts + rng.exponential(30 * DAY))
            net.detail[s] = f"copy={frac:.2f};window_h={window:.0f};pfollow={pf:.2f}"

    profiles = pd.DataFrame({"id": np.arange(len(net.t0)), "t0": net.t0, "name": net.name,
                             "name_time": net.name_time, "community": net.comm, "onboarding": net.onb})
    edges = pd.DataFrame([(u, v, t) for (u, v), t in net.edges.items()], columns=["src", "dst", "t"])
    edges = edges.sort_values("t", kind="stable").reset_index(drop=True)
    labels = pd.DataFrame({"id": np.arange(len(net.t0)), "role": net.role, "target": net.target, "detail": net.detail})
    return profiles, edges, labels


# --------------------------------------------------------------------------
# Named configurations used in the paper
# --------------------------------------------------------------------------
def config(name: str, **over) -> GenParams:
    if name == "base":
        p = GenParams()
    elif name == "original_design":
        p = GenParams(n_ordinary=952, n_victims=12, namesakes_per_victim=1, n_dormant=0, n_secondary=0,
                      onboarding_frac=0.0, victim_boost=True, original_design=True)
    elif name == "isolated":     # used by the controlled grid: no secondary or dormant accounts
        p = GenParams(n_dormant=0, n_secondary=0)
    else:
        raise ValueError(name)
    for k, v in over.items():
        setattr(p, k, v)
    return p
