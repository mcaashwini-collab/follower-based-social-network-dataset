"""Evaluation utilities: per-network scoring, calibration, metrics, bootstrap, replay."""
from __future__ import annotations

from collections import defaultdict

import numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score

from . import detector as D
from .generator import generate, T_END

ATTACK = {"clone", "dormant_attacker"}
CHECKPOINTS_H = {"1 h": 1, "48 h": 48, "7 d": 7 * 24, "30 d": 30 * 24, "90 d": 90 * 24,
                 "180 d": 180 * 24, "365 d": 365 * 24}


class NetworkEval:
    """All pair- and account-level quantities of one generated network."""

    def __init__(self, params, seed, ordering="name_time", kappa=0.0, T=T_END, data=None):
        self.params, self.seed, self.ordering, self.kappa, self.T = params, seed, ordering, kappa, T
        prof, edges, lab = data if data is not None else generate(params, seed)
        self.prof, self.edges, self.lab = prof, edges, lab
        self.n = len(prof)
        self.t_ref = (prof.name_time if ordering == "name_time" else prof.t0).to_numpy()
        self.role = lab.role.to_numpy()
        self.target = lab.target.to_numpy()
        self.is_attack = np.isin(self.role, list(ATTACK))
        self.pairs = D.screen_indexed(prof.name.tolist(), self.t_ref)
        self.G = D.TemporalGraph(self.n, edges)
        keys = list(self.pairs)
        self.pair_keys = keys
        self.sig = np.array([D.signals(self.G, A, B, self.pairs[(A, B)], self.t_ref, T, kappa) for A, B in keys]) \
            if keys else np.zeros((0, 8))
        self.pair_label = np.array([self._pair_label(A, B) for A, B in keys], dtype=int)  # 1 pos, 0 neg, -1 sibling
        self.extra = {}

    def _pair_label(self, A, B):
        if self.role[B] in ATTACK and self.target[B] == A:
            return 1
        if self.role[A] in ATTACK and self.role[B] in ATTACK and self.target[A] == self.target[B]:
            return -1
        # renamed dormant attacker processed before its victim under creation ordering
        if self.role[A] in ATTACK and self.target[A] == B:
            return 1 if self.ordering == "name_time" else 0
        return 0

    # ---- pair scores for a method --------------------------------------
    def pair_scores(self, method, w=None, model=None):
        if method in D.SUBSETS:
            idx = D.SUBSETS[method]
            return self.sig[:, idx].mean(axis=1) if len(self.sig) else np.zeros(0)
        if method == "weights":
            return self.sig @ w
        if method == "Neighbourhood similarity, adapted from [1]":
            return np.array([D.neighbourhood_score(self.G, A, B, self.pairs[(A, B)], self.T) for A, B in self.pair_keys])
        if method == "Attribute + followee containment (Jin et al.-style)":
            return np.array([D.containment_score(self.G, A, B, self.pairs[(A, B)], self.T) for A, B in self.pair_keys])
        if method == "Supervised logistic regression (reference)":
            return model.predict_proba(self.sig)[:, 1] if len(self.sig) else np.zeros(0)
        raise ValueError(method)

    def account_scores(self, ps):
        """Score of an account = highest pair score among pairs in which it is the suspect B."""
        s = np.zeros(self.n)
        best = {}
        for (A, B), v in zip(self.pair_keys, ps):
            if B not in best or v > s[B]:
                s[B] = v
                best[B] = A
        return s, best

    def burst_account_scores(self):
        return np.array([D.burst_score_account(self.G, v, self.t_ref, self.T) for v in range(self.n)])

    def via(self, best):
        att = np.where(self.is_attack)[0]
        hits = [best.get(int(b), -1) == self.target[b] for b in att]
        return float(np.mean(hits)) if len(hits) else np.nan

    def screening_recall(self):
        att = np.where(self.is_attack)[0]
        ok = 0
        for b in att:
            v = self.target[b]
            if (v, b) in self.pairs or (b, v) in self.pairs:
                ok += 1
        return ok / len(att) if len(att) else np.nan


# --------------------------------------------------------------------------
def calibrate(scores, labels, prec_target=0.99, rec_target=0.95):
    """HIGH threshold: smallest t with precision >= prec_target (pooled).
    MEDIUM threshold: largest t with recall >= rec_target."""
    grid = np.round(np.arange(0.20, 1.0001, 0.005), 3)
    tH, tM = None, None
    P = labels.sum()
    for t in grid:
        pred = scores >= t
        tp = (pred & (labels == 1)).sum()
        fp = (pred & (labels == 0)).sum()
        if tp > 0 and tp / (tp + fp) >= prec_target and tH is None:
            tH = float(t)
        if P and tp / P >= rec_target:
            tM = float(t)
    if tH is None:          # no operating point reaches the precision target: nothing is auto-reported
        tH = float("inf")
    if tM is None:
        tM = float(grid[0])
    tM = min(tM, tH) if np.isfinite(tH) else tM
    return tH, tM


def account_metrics(scores, labels, tH, tM):
    out = {}
    y = labels.astype(int)
    out["roc_auc"] = float(roc_auc_score(y, scores)) if 0 < y.sum() < len(y) else np.nan
    out["ap"] = float(average_precision_score(y, scores)) if y.sum() > 0 else np.nan
    H = scores >= tH
    M = (scores >= tM) & ~H
    tp = int((H & (y == 1)).sum()); fp = int((H & (y == 0)).sum())
    out["high_recall"] = tp / y.sum() if y.sum() else np.nan
    out["high_precision"] = tp / (tp + fp) if tp + fp else np.nan
    out["high_fp"] = fp
    out["high_fp_per_10k"] = fp / len(y) * 1e4
    q = int(M.sum()); qtp = int((M & (y == 1)).sum())
    out["queue_per_1k"] = q / len(y) * 1e3
    out["queue_precision"] = qtp / q if q else np.nan
    out["reported_or_queued_recall"] = int(((H | M) & (y == 1)).sum()) / y.sum() if y.sum() else np.nan
    out["missed"] = int((~(H | M) & (y == 1)).sum())
    return out


def pair_auc(ps, pl):
    m = pl >= 0
    y = pl[m]
    if y.sum() == 0 or y.sum() == len(y):
        return np.nan
    return float(roc_auc_score(y, ps[m]))


# --------------------------------------------------------------------------
def candidate_components(ne: NetworkEval):
    """Independent resampling units: connected components of the candidate-pair graph;
    every profile in no candidate pair is its own unit."""
    parent = list(range(ne.n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for A, B in ne.pair_keys:
        ra, rb = find(A), find(B)
        if ra != rb:
            parent[ra] = rb
    comp = defaultdict(list)
    for v in range(ne.n):
        comp[find(v)].append(v)
    return list(comp.values())


def cluster_bootstrap_auc(scores, labels, units, B=1000, seed=0):
    rng = np.random.default_rng(seed)
    units = [np.array(u) for u in units]
    vals, aps = [], []
    for _ in range(B):
        pick = rng.integers(0, len(units), len(units))
        idx = np.concatenate([units[i] for i in pick])
        y = labels[idx]
        if 0 < y.sum() < len(y):
            vals.append(roc_auc_score(y, scores[idx]))
            aps.append(average_precision_score(y, scores[idx]))
    vals, aps = np.array(vals), np.array(aps)
    return (float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5)), float((vals == 1.0).mean()),
            float(np.percentile(aps, 2.5)), float(np.percentile(aps, 97.5)))


# --------------------------------------------------------------------------
def replay(ne: NetworkEval, tH, tM, kappa):
    """Chronological evaluation: the score of each suspect is recomputed at fixed
    offsets after it adopted its name, using only edges that existed then.
    Returns per-checkpoint counts (attackers reported/queued, benign alarms) and
    the first-detection offsets of each attacker."""
    by_B = defaultdict(list)
    for (A, B) in ne.pair_keys:
        by_B[B].append(A)
    res = {k: {"att_eval": 0, "att_high": 0, "att_flag": 0, "ben_eval": 0, "ben_high": 0, "ben_flag": 0}
           for k in CHECKPOINTS_H}
    first_high, first_flag = {}, {}
    for B, As in by_B.items():
        for label, off in CHECKPOINTS_H.items():
            T = ne.t_ref[B] + off
            if T > T_END:
                continue
            s = max(D.css(D.signals(ne.G, A, B, ne.pairs[(A, B)], ne.t_ref, T, kappa)) for A in As)
            r = res[label]
            if ne.is_attack[B]:
                r["att_eval"] += 1
                r["att_high"] += s >= tH
                r["att_flag"] += s >= tM
                if s >= tH and B not in first_high:
                    first_high[B] = off
                if s >= tM and B not in first_flag:
                    first_flag[B] = off
            else:
                r["ben_eval"] += 1
                r["ben_high"] += s >= tH
                r["ben_flag"] += s >= tM
    att = [int(b) for b in np.where(ne.is_attack)[0]]
    return res, {b: first_high.get(b) for b in att}, {b: first_flag.get(b) for b in att}
