"""Runtime and memory of screening and verification versus network size and
name-collision level (R1.8).  Writes results/runtime.csv."""
import os, sys, time, json, tracemalloc, platform
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from clonedet.generator import generate, config
from clonedet import detector as D

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
SIZES = [int(x) for x in os.environ.get("SIZES", "1000,2000,5000,10000,20000").split(",")]
EXH_MAX = {0.0: 5000, 0.5: 10000, 0.8: 5000}
ZIPFS = [float(x) for x in os.environ.get("ZIPFS", "0.0,0.5,0.8").split(",")]


def timed(f, *a):
    t = time.perf_counter(); r = f(*a); return r, time.perf_counter() - t


def peak(f, *a):
    tracemalloc.start(); f(*a); _, p = tracemalloc.get_traced_memory(); tracemalloc.stop(); return p / 2**20


rows = pd.read_csv(os.path.join(OUT, "runtime.csv")).to_dict("records") if os.environ.get("APPEND") else []
for z in ZIPFS:
    for n in SIZES:
        prm = config("isolated", n_ordinary=n, n_victims=max(10, n // 150), name_zipf=z)
        (prof, edges, lab), tg = timed(generate, prm, 11)
        names = prof.name.tolist(); tr = prof.name_time.to_numpy()
        pairs, t_idx = timed(D.screen_indexed, names, tr)
        m_idx = peak(D.screen_indexed, names, tr)
        row = {"zipf": z, "n": len(prof), "edges": len(edges), "k_pairs": len(pairs),
               "screen_indexed_s": t_idx, "screen_indexed_peak_MiB": m_idx,
               "all_pairs": len(prof) * (len(prof) - 1) // 2}
        if n <= EXH_MAX[z]:
            pe, t_ex = timed(D.screen_exhaustive, names, tr)
            row["screen_exhaustive_s"] = t_ex
            row["identical_candidate_sets"] = bool(pe == pairs)
            if n <= 5000:
                row["screen_exhaustive_peak_MiB"] = peak(D.screen_exhaustive, names, tr)
        G, t_g = timed(D.TemporalGraph, len(prof), edges)
        T = float(edges.t.max())

        def verify():
            return [D.signals(G, A, B, j, tr, T, 32) for (A, B), j in pairs.items()]
        _, t_v = timed(verify)
        row.update({"graph_build_s": t_g, "verify_s": t_v,
                    "verify_us_per_pair": t_v / max(1, len(pairs)) * 1e6})
        rows.append(row)
        print(json.dumps(row), flush=True)
        pd.DataFrame(rows).to_csv(os.path.join(OUT, "runtime.csv"), index=False)

info = {"python": platform.python_version(), "machine": platform.machine(), "processor": platform.processor()}
try:
    info["cpu"] = [l.split(":", 1)[1].strip() for l in open("/proc/cpuinfo") if l.startswith("model name")][0]
    info["mem_GiB"] = round(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 2**30, 1)
    info["cores"] = os.cpu_count()
except Exception:
    pass
json.dump(info, open(os.path.join(OUT, "runtime_env.json"), "w"), indent=1)
