"""Runs every experiment of the revised manuscript and writes results/*.json|csv.

Seeds: calibration 1-10, main test 101-130, controlled grid 201-208,
stability calibration 301-305 / test 311-318, original design 401-430.
Usage: python run_experiments.py [stage ...]   (default: all stages)
"""
import json, sys, time, os
from multiprocessing import Pool
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from clonedet.generator import config, generate, T_END, YEAR
from clonedet import detector as D
from clonedet.evaluate import (NetworkEval, calibrate, account_metrics, pair_auc, candidate_components,
                               cluster_bootstrap_auc, replay, CHECKPOINTS_H, ATTACK)

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
os.makedirs(OUT, exist_ok=True)
CAL_SEEDS = list(range(1, 11))
TEST_SEEDS = list(range(101, 131))
KAPPAS = [0, 1, 2, 4, 8, 16, 32]
PAIR_METHODS = ["CSS (full)", "CSS static terms (J, S1, S2, S7)", "CSS temporal terms (S3-S6)",
                "Static overlap rule (J, S2, S7)", "Name similarity only",
                "Neighbourhood similarity, adapted from [1]",
                "Attribute + followee containment (Jin et al.-style)",
                "Supervised logistic regression (reference)"]
BURST = "Burst rule (S3 on every account)"


def dump(name, obj):
    with open(os.path.join(OUT, name), "w") as f:
        json.dump(obj, f, indent=1, default=float)


def load(name):
    with open(os.path.join(OUT, name)) as f:
        return json.load(f)


# ---------------------------------------------------------------- calibration
def _cal_one(args):
    seed, kappas = args
    data = generate(config("base"), seed)
    out = {}
    for k in kappas:
        ne = NetworkEval(None, seed, kappa=k, data=data)
        out[k] = ne
    return seed, out


def stage_calibration():
    t = time.time()
    with Pool(2) as p:
        res = dict(p.map(_cal_one, [(s, KAPPAS) for s in CAL_SEEDS]))
    # choose kappa by pooled account-level AP of the full CSS
    ap_by_k = {}
    for k in KAPPAS:
        sc, y = [], []
        for s in CAL_SEEDS:
            ne = res[s][k]
            a, _ = ne.account_scores(ne.pair_scores("CSS (full)"))
            sc.append(a); y.append(ne.is_attack.astype(int))
        ap_by_k[k] = float(average_precision_score(np.concatenate(y), np.concatenate(sc)))
    kappa = max(ap_by_k, key=lambda k: (round(ap_by_k[k], 4), -k))
    nets = [res[s][kappa] for s in CAL_SEEDS]
    # supervised reference model trained on calibration pairs
    X = np.vstack([ne.sig[ne.pair_label >= 0] for ne in nets])
    yv = np.concatenate([ne.pair_label[ne.pair_label >= 0] for ne in nets])
    lr = LogisticRegression(class_weight="balanced", max_iter=2000).fit(X, yv)
    thr = {}
    for m in PAIR_METHODS + [BURST]:
        sc, y = [], []
        for ne in nets:
            if m == BURST:
                a = ne.burst_account_scores()
            else:
                a, _ = ne.account_scores(ne.pair_scores(m, model=lr))
            sc.append(a); y.append(ne.is_attack.astype(int))
        thr[m] = calibrate(np.concatenate(sc), np.concatenate(y))
    cal = {"kappa": kappa, "ap_by_kappa": ap_by_k, "thresholds": thr,
           "lr_coef": lr.coef_.tolist(), "lr_intercept": lr.intercept_.tolist(),
           "n_cal_accounts": int(sum(ne.n for ne in nets)),
           "n_cal_attackers": int(sum(ne.is_attack.sum() for ne in nets))}
    dump("calibration.json", cal)
    print("calibration", round(time.time() - t), "s", cal["kappa"], cal["thresholds"]["CSS (full)"])
    return cal


def get_lr(cal):
    lr = LogisticRegression()
    lr.classes_ = np.array([0, 1]); lr.coef_ = np.array(cal["lr_coef"]); lr.intercept_ = np.array(cal["lr_intercept"])
    return lr


# ---------------------------------------------------------------- main test
def _main_one(args):
    seed, cal = args[:2]
    over = args[2] if len(args) > 2 else {}
    kappa = cal["kappa"]; thr = cal["thresholds"]; lr = get_lr(cal)
    data = generate(config("base", **over), seed)
    ne = NetworkEval(None, seed, kappa=kappa, data=data)
    y = ne.is_attack.astype(int)
    row = {"seed": seed, "n": ne.n, "attackers": int(y.sum()), "pairs": len(ne.pair_keys),
           "c_set": len({b for _, b in ne.pair_keys}), "screen_recall": ne.screening_recall()}
    methods = {}
    roles_flag = {}
    for m in PAIR_METHODS + [BURST]:
        if m == BURST:
            a = ne.burst_account_scores(); best = None; ps = None
        else:
            ps = ne.pair_scores(m, model=lr)
            a, best = ne.account_scores(ps)
        tH, tM = thr[m]
        r = account_metrics(a, y, tH, tM)
        cs = np.array(sorted({b for _, b in ne.pair_keys}))
        r["roc_auc_cset"] = float(roc_auc_score(y[cs], a[cs])) if 0 < y[cs].sum() < len(cs) else np.nan
        if best is not None:
            r["via"] = ne.via(best)
            r["pair_auc"] = pair_auc(ps, ne.pair_label)
        if m == "CSS (full)":
            lo, hi, frac1, alo, ahi = cluster_bootstrap_auc(a, y, candidate_components(ne), B=500, seed=seed)
            r["boot_auc_lo"], r["boot_auc_hi"], r["boot_frac_perfect"] = lo, hi, frac1
            r["boot_ap_lo"], r["boot_ap_hi"] = alo, ahi
            r["n_units"] = len(candidate_components(ne))
            H = a >= tH; M = (a >= tM) & ~H
            for role in ["clone", "dormant_attacker", "secondary", "namesake", "victim", "owner", "ordinary"]:
                msk = ne.role == role
                roles_flag[role] = {"n": int(msk.sum()), "high": int((H & msk).sum()), "medium": int((M & msk).sum())}
            # per-attacker detail
            r["attackers"] = [{"id": int(b), "role": ne.role[b], "detail": ne.lab.detail[b], "score": float(a[b]),
                               "band": "HIGH" if a[b] >= tH else ("MEDIUM" if a[b] >= tM else "LOW"),
                               "victim_ok": bool(best.get(int(b), -1) == ne.target[b])}
                              for b in np.where(ne.is_attack)[0]]
            # pair-level table by pair type
            types = []
            for (A, B), lab, s in zip(ne.pair_keys, ne.pair_label, ps):
                rb, ra = ne.role[B], ne.role[A]
                if lab == 1: t_ = "attacker-victim"
                elif lab == -1: t_ = "sibling"
                elif rb in ATTACK: t_ = "attacker-other"
                elif rb == "namesake" or ra == "namesake": t_ = "namesake pair"
                elif rb == "secondary" and ne.target[B] == A: t_ = "secondary-owner"
                else: t_ = "other benign"
                types.append((t_, float(s)))
            r["pair_types"] = types
        methods[m] = r
    # signals of attacker-victim pairs (for the signal table)
    sigrows = []
    for (A, B), lab, sg in zip(ne.pair_keys, ne.pair_label, ne.sig):
        rb = ne.role[B]
        kind = ("attacker-victim" if lab == 1 else "sibling" if lab == -1 else
                "secondary-owner" if (rb == "secondary" and ne.target[B] == A) else
                "namesake pair" if ("namesake" in (rb, ne.role[A])) else
                "attacker-other" if rb in ATTACK else "other benign")
        sigrows.append([kind] + [float(x) for x in sg])
    row["methods"] = methods; row["roles"] = roles_flag; row["sig"] = sigrows
    # creation-time ordering (original submission) on the same network
    ne_c = NetworkEval(None, seed, ordering="creation", kappa=kappa, data=data)
    a_c, best_c = ne_c.account_scores(ne_c.pair_scores("CSS (full)"))
    tH, tM = thr["CSS (full)"]
    dorm = np.where(ne.role == "dormant_attacker")[0]
    a_n, best_n = ne.account_scores(ne.pair_scores("CSS (full)"))
    vic = np.unique(ne.target[dorm]) if len(dorm) else np.array([], int)
    row["dormant"] = {
        "n": int(len(dorm)),
        "name_time": {"flagged": int((a_n[dorm] >= tM).sum()), "high": int((a_n[dorm] >= tH).sum()),
                      "victim_ok": int(sum(best_n.get(int(b), -1) == ne.target[b] for b in dorm)),
                      "victims_flagged": int((a_n[vic] >= tM).sum()) if len(vic) else 0},
        "creation": {"flagged": int((a_c[dorm] >= tM).sum()), "high": int((a_c[dorm] >= tH).sum()),
                     "victim_ok": int(sum(best_c.get(int(b), -1) == ne.target[b] for b in dorm)),
                     "victims_flagged": int((a_c[vic] >= tM).sum()) if len(vic) else 0}}
    # onboarding / burst-rule harm (R2.6)
    b = ne.burst_account_scores()
    recent = (ne.t_ref >= T_END - 2 * YEAR)
    benign = ~ne.is_attack
    row["burst"] = {"benign_recent": int((benign & recent).sum()),
                    "benign_recent_over_090": int((benign & recent & (b > 0.9)).sum()),
                    "benign_all_over_090": int((benign & (b > 0.9)).sum()),
                    "onboarding_recent": int((benign & recent & ne.prof.onboarding.to_numpy()).sum()),
                    "onboarding_recent_over_090": int((benign & recent & ne.prof.onboarding.to_numpy() & (b > 0.9)).sum()),
                    "attackers_over_090": int((ne.is_attack & (b > 0.9)).sum()),
                    "secondary_over_090": int(((ne.role == "secondary") & (b > 0.9)).sum())}
    # chronological replay
    tH, tM = thr["CSS (full)"]
    rep, fh, ff = replay(ne, tH, tM, kappa)
    row["replay"] = rep
    row["first_high"] = {str(k): v for k, v in fh.items()}
    row["first_flag"] = {str(k): v for k, v in ff.items()}
    return row


def stage_main():
    cal = load("calibration.json")
    t = time.time()
    with Pool(2) as p:
        rows = p.map(_main_one, [(s, cal) for s in TEST_SEEDS])
    dump("main_test.json", rows)
    print("main", round(time.time() - t), "s")


def stage_secondary():
    """Stress scenario: authorised secondary accounts are six times more common (R2.3, R2.4)."""
    cal = load("calibration.json")
    with Pool(2) as p:
        rows = p.map(_main_one, [(s, cal, {"n_secondary": 30}) for s in TEST_SEEDS[:10]])
    for r_ in rows:
        r_.pop("sig", None); r_.pop("replay", None)
        for m in r_["methods"].values():
            m.pop("pair_types", None)
    dump("secondary_stress.json", rows)
    print("secondary stress done")


# ---------------------------------------------------------------- grid (R1.4)
def _grid_one(args):
    o, burst, speed, seed, kappa = args
    prm = config("isolated", namesake_overlap=(o, o), namesake_burst_frac=float(burst),
                 copy_speed={speed: 1.0}, namesakes_per_victim=2, n_victims=20)
    ne = NetworkEval(prm, seed, kappa=kappa)
    out = {"o": o, "burst": burst, "speed": speed, "seed": seed}
    # pairs that contain a namesake are the hard negatives of interest
    nm = np.array([("namesake" in (ne.role[A], ne.role[B])) for A, B in ne.pair_keys])
    keep = (ne.pair_label == 1) | ((ne.pair_label == 0) & nm)
    y = ne.pair_label[keep]
    for m in ["CSS (full)", "CSS static terms (J, S1, S2, S7)", "CSS temporal terms (S3-S6)", "Name similarity only"]:
        ps = ne.pair_scores(m)[keep]
        out[m] = float(roc_auc_score(y, ps)) if 0 < y.sum() < len(y) else np.nan
        out[m + "|AP"] = float(average_precision_score(y, ps)) if y.sum() else np.nan
    return out


def stage_grid():
    cal = load("calibration.json")
    jobs = [(o, b, s, seed, cal["kappa"]) for o in [0.0, 0.2, 0.4, 0.6, 0.8] for b in [0, 1]
            for s in ["48h", "2w", "90d"] for seed in range(201, 209)]
    t = time.time()
    with Pool(2) as p:
        rows = p.map(_grid_one, jobs)
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "grid.csv"), index=False)
    print("grid", round(time.time() - t), "s")


# ---------------------------------------------------------------- stability (R2.5)
def _stab_one(args):
    nv, mo, seed, kappa = args
    ne = NetworkEval(config("base", n_victims=nv, mean_out=mo), seed, kappa=kappa)
    a, best = ne.account_scores(ne.pair_scores("CSS (full)"))
    return {"nv": nv, "mean_out": mo, "seed": seed, "scores": a.tolist(), "y": ne.is_attack.astype(int).tolist(),
            "via": ne.via(best)}


def stage_stability():
    cal = load("calibration.json")
    tH0, tM0 = cal["thresholds"]["CSS (full)"]
    conds = [(nv, mo) for nv in [8, 15, 40, 75] for mo in [5.0, 15.0, 40.0]]
    jobs = [(nv, mo, s, cal["kappa"]) for nv, mo in conds for s in list(range(301, 306)) + list(range(311, 319))]
    t = time.time()
    with Pool(2) as p:
        rows = p.map(_stab_one, jobs)
    out = []
    for nv, mo in conds:
        calr = [r for r in rows if r["nv"] == nv and r["mean_out"] == mo and r["seed"] < 310]
        tst = [r for r in rows if r["nv"] == nv and r["mean_out"] == mo and r["seed"] > 310]
        tH, tM = calibrate(np.concatenate([r["scores"] for r in calr]), np.concatenate([r["y"] for r in calr]))
        res = {"n_victims": nv, "mean_out": mo, "tH_recal": tH, "tM_recal": tM}
        prev = []
        for lab, (h, m) in {"frozen": (tH0, tM0), "recal": (tH, tM)}.items():
            ms = [account_metrics(np.array(r["scores"]), np.array(r["y"]), h, m) for r in tst]
            for k in ["ap", "high_precision", "high_recall", "high_fp_per_10k", "queue_per_1k", "queue_precision",
                      "reported_or_queued_recall"]:
                vals = [x[k] for x in ms]
                res[f"{lab}_{k}"] = float(np.nanmean(vals))
                res[f"{lab}_{k}_sd"] = float(np.nanstd(vals))
        res["prevalence"] = float(np.mean([np.mean(r["y"]) for r in tst]))
        res["via"] = float(np.mean([r["via"] for r in tst]))
        out.append(res)
    pd.DataFrame(out).to_csv(os.path.join(OUT, "stability.csv"), index=False)
    print("stability", round(time.time() - t), "s")


# ---------------------------------------------------------------- original design
def _orig_one(args):
    seed, kappa = args
    ne = NetworkEval(config("original_design"), seed, kappa=kappa)
    out = {"seed": seed, "n": ne.n, "pairs": len(ne.pair_keys)}
    for m in ["CSS (full)", "CSS static terms (J, S1, S2, S7)", "CSS temporal terms (S3-S6)", "Name similarity only"]:
        ps = ne.pair_scores(m)
        a, best = ne.account_scores(ps)
        y = ne.is_attack.astype(int)
        out[m] = {"pair_auc": pair_auc(ps, ne.pair_label), "ap": float(average_precision_score(y, a)), "via": ne.via(best)}
    return out


def stage_original():
    cal = load("calibration.json")
    with Pool(2) as p:
        rows = p.map(_orig_one, [(s, cal["kappa"]) for s in range(401, 431)])
    dump("original_design.json", rows)
    print("original design done")


# ---------------------------------------------------------------- weights
def _w_one(args):
    seed, kappa = args
    ne = NetworkEval(config("base"), seed, kappa=kappa)
    return ne.sig.tolist(), [list(k) for k in ne.pair_keys], ne.is_attack.astype(int).tolist(), ne.n, ne.target.tolist()


def stage_weights():
    cal = load("calibration.json")
    with Pool(2) as p:
        nets = p.map(_w_one, [(s, cal["kappa"]) for s in TEST_SEEDS])
    rng = np.random.default_rng(7)
    W = rng.dirichlet(np.ones(8), 2000)
    W = np.vstack([np.full(8, 1 / 8), W])
    aps, vias = [], []
    prepared = []
    for sig, keys, y, n, target in nets:
        sig = np.array(sig); B = np.array([k[1] for k in keys]); A = np.array([k[0] for k in keys])
        prepared.append((sig, A, B, np.array(y), n, np.array(target)))
    for w in W:
        ap_n, via_n = [], []
        for sig, A, B, y, n, target in prepared:
            ps = sig @ w
            s = np.zeros(n); best = np.full(n, -1)
            order = np.argsort(ps)
            s[B[order]] = ps[order]; best[B[order]] = A[order]
            ap_n.append(average_precision_score(y, s))
            att = np.where(y == 1)[0]
            via_n.append(np.mean(best[att] == target[att]))
        aps.append(np.mean(ap_n)); vias.append(np.mean(via_n))
    dump("weights.json", {"weights": W.tolist(), "mean_ap": aps, "mean_via": vias})
    print("weights done")


if __name__ == "__main__":
    stages = sys.argv[1:] or ["calibration", "main", "secondary", "grid", "stability", "original", "weights"]
    for s in stages:
        globals()["stage_" + s]()
