"""Checks every released network: the CSV files equal a fresh regeneration from the seed, edges are
valid (no duplicates, self-loops or edges outside the observation window), labels are consistent, per-pair
signals recompute exactly from the CSV files alone, and the Table 9 counts are reproduced.
Usage: python verify_dataset.py   ->  results/dataset_check.json"""
import os, sys, json, collections
import numpy as np, pandas as pd
from multiprocessing import Pool
R = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, R)
from clonedet.generator import generate, config, T_END, YEAR
from clonedet.evaluate import NetworkEval
KAPPA = json.load(open(f"{R}/results/calibration.json"))["kappa"]
splits = {"calibration": ("base", range(1, 11)), "test": ("base", range(101, 131)), "original_design": ("original_design", range(401, 431))}
H = lambda y: (y - 2010) * YEAR

def check(arg):
    split, cfg, s = arg
    d = f"{R}/data/{split}/seed_{s:03d}"; issues = []
    P = pd.read_csv(f"{d}/profiles.csv", keep_default_na=False); E = pd.read_csv(f"{d}/edges.csv"); L = pd.read_csv(f"{d}/labels.csv", keep_default_na=False)
    prm = json.load(open(f"{d}/params.json"))
    if prm["seed"] != s or prm["config"] != cfg: issues.append("params seed/config")
    if json.loads(json.dumps(config(cfg).to_dict(), default=str)) != prm["params"]: issues.append("params differ from config")
    p, e, l = generate(config(cfg), s)
    # profiles
    if len(P) != len(p) or not (P.id.values == np.arange(len(P))).all(): issues.append("profile ids")
    if list(P.name) != list(p.name): issues.append("names")
    for c in ["t0", "name_time"]:
        if np.abs(P[c].values - p[c].values).max() > 1e-6: issues.append(c)
    if not (P.community.values == p.community.values).all(): issues.append("community")
    if not (P.onboarding.astype(str).values == p.onboarding.astype(str).values).all(): issues.append("onboarding")
    # edges
    if len(E) != len(e): issues.append(f"edge count {len(E)} vs {len(e)}")
    else:
        if not ((E.src.values == e.src.values).all() and (E.dst.values == e.dst.values).all()): issues.append("edge endpoints")
        if np.abs(E.t.values - e.t.values).max() > 6e-5: issues.append("edge times")
    dup = E.duplicated(["src", "dst"]).sum(); selfl = (E.src == E.dst).sum()
    if dup: issues.append(f"{dup} duplicate edges")
    if selfl: issues.append(f"{selfl} self loops")
    if (E.t > T_END + 1e-6).any(): issues.append("edges after observation end")
    t0 = P.t0.values
    if (E.t.values < np.maximum(t0[E.src.values], t0[E.dst.values]) - 1e-3).any(): issues.append("edge before an endpoint existed")
    # labels
    if list(L.role) != list(l.role) or list(L.target) != list(l.target) or list(L.detail.astype(str)) != list(l.detail.fillna("").astype(str)): issues.append("labels")
    roles = collections.Counter(L.role)
    # attack sanity
    for _, r in L[L.role.isin(["clone", "dormant_attacker", "namesake"])].iterrows():
        v = r.target
        if L.role[v] != "victim": issues.append(f"{r.id} target not a victim")
        if r.role == "clone" and P.name_time[r.id] < P.t0[v] + YEAR - 1e-6 and cfg == "base": issues.append(f"clone {r.id} < 1y after victim")
    for _, r in L[L.role == "secondary"].iterrows():
        if L.role[r.target] != "owner": issues.append(f"secondary {r.id} owner role")
    rec = {"split": split, "seed": s, "n": len(P), "m": len(E), "roles": dict(roles), "issues": issues,
           "mean_out": len(E) / len(P), "victim_years": [((P.t0[v]) / YEAR + 2010) for v in L.id[L.role == "victim"]],
           "pert": collections.Counter(x.split("pert=")[1].split(";")[0] for x in L.detail[L.role.isin(["clone", "dormant_attacker"])] if "pert=" in x),
           "namesake_exact": int(sum(P.name[r.id] == P.name[r.target] for _, r in L[L.role == "namesake"].iterrows()))}
    if split == "test":
        S = pd.read_csv(f"{d}/pair_signals.csv")
        # recompute FROM THE RELEASED CSV FILES, not from the generator
        ne = NetworkEval(None, s, kappa=KAPPA, data=(P.assign(onboarding=P.onboarding.astype(str) == "True"), E, L))
        sig = ne.sig
        if len(S) != len(ne.pair_keys): issues.append("pair count")
        else:
            if not ((S.A.values == [a for a, _ in ne.pair_keys]).all() and (S.B.values == [b for _, b in ne.pair_keys]).all()): issues.append("pair order")
            if np.abs(S[["J_name", "S1", "S2", "S3", "S4", "S5", "S6", "S7"]].values - sig).max() > 1e-5: issues.append("pair signals differ when recomputed from CSV")
            if np.abs(S.CSS.values - S[["J_name", "S1", "S2", "S3", "S4", "S5", "S6", "S7"]].values.mean(1)).max() > 1e-5: issues.append("CSS != mean")
            if not (S.label.values == ne.pair_label).all(): issues.append("pair labels")
        tH, tM = json.load(open(f"{R}/results/calibration.json"))["thresholds"]["CSS (full)"]
        a, _ = ne.account_scores(ne.pair_scores("CSS (full)"))
        rec["roles_flag"] = {ro: [int((ne.role == ro).sum()), int(((a >= tH) & (ne.role == ro)).sum()), int(((a >= tM) & (a < tH) & (ne.role == ro)).sum())]
                             for ro in ["clone", "dormant_attacker", "secondary", "namesake", "victim", "owner", "ordinary"]}
        rec["screen_recall"] = ne.screening_recall()
    rec["pert"] = dict(rec["pert"])
    return rec

if __name__ == "__main__":
    jobs = [(sp, cfg, s) for sp, (cfg, ss) in splits.items() for s in ss]
    with Pool(2) as pool: res = pool.map(check, jobs)
    json.dump(res, open(os.path.join(R, "results", "dataset_check.json"), "w"), indent=1, default=float)
    bad = [(r["split"], r["seed"], r["issues"]) for r in res if r["issues"]]
    print("networks checked:", len(res), "with issues:", len(bad))
    for b in bad[:20]: print(b)
