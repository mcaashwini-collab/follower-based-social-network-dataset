"""Section 6.4: endpoint snapshot versus cumulative rule (reviewer comment on 26 vs 49).

For every account of the 30 test networks, the CSS band is computed
  (a) once on the graph at the end of observation (endpoint snapshot, Tables 7 and 9), and
  (b) at every replay checkpoint (1 h, 48 h, 7/30/90/180/365 d after t_ref) that falls before the end,
and the cumulative band is max(a, b) -- the rule of Section 4.5.
For the attackers that were flagged at a checkpoint but not at the endpoint, the mean signals at the
first flag and at the end of observation are also reported.
Output: results/cumulative_counts.json.   Usage: python cumulative_counts.py
"""
import os, sys, json, collections
from multiprocessing import Pool
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from clonedet.generator import config, generate, T_END
from clonedet import detector as D
from clonedet.evaluate import NetworkEval, CHECKPOINTS_H

cal = json.load(open(os.path.join(HERE, "results", "calibration.json")))
K = cal["kappa"]; tH, tM = cal["thresholds"]["CSS (full)"]
ROLES = ["clone", "dormant_attacker", "secondary", "namesake", "victim", "owner", "ordinary"]
NAMES = ["J", "S1", "S2", "S3", "S4", "S5", "S6", "S7"]
band = lambda s: 2 if s >= tH else 1 if s >= tM else 0


def one(seed):
    ne = NetworkEval(None, seed, kappa=K, data=generate(config("base"), seed))
    a, _ = ne.account_scores(ne.pair_scores("CSS (full)"))
    end = np.array([band(s) for s in a])
    cp = np.zeros(ne.n, int); first = {}
    by_B = collections.defaultdict(list)
    for A, B in ne.pair_keys: by_B[B].append(A)
    for B, As in by_B.items():
        for off in sorted(CHECKPOINTS_H.values()):
            T = ne.t_ref[B] + off
            if T > T_END: continue
            b = band(max(D.css(D.signals(ne.G, A, B, ne.pairs[(A, B)], ne.t_ref, T, K)) for A in As))
            if b and B not in first: first[B] = off
            cp[B] = max(cp[B], b)
    cum = np.maximum(cp, end)
    out = {"n": ne.n, "roles": {}}
    for r in ROLES:
        m = ne.role == r
        out["roles"][r] = dict(n=int(m.sum()), endpoint_flagged=int((end[m] > 0).sum()), endpoint_high=int((end[m] == 2).sum()),
                               cumulative_flagged=int((cum[m] > 0).sum()), cumulative_high=int((cum[m] == 2).sum()),
                               checkpoint_only=int(((cp[m] > 0) & (end[m] == 0)).sum()),
                               endpoint_only=int(((cp[m] == 0) & (end[m] > 0)).sum()))
    sig = []
    for B in np.where(ne.is_attack & (cp > 0) & (end == 0))[0]:
        A = int(ne.target[B])
        sig.append({"seed": seed, "id": int(B), "first_flag_h": first[B], "endpoint_css": float(a[B]),
                    "at_first": list(map(float, D.signals(ne.G, A, B, ne.pairs[(A, B)], ne.t_ref, ne.t_ref[B] + first[B], K))),
                    "at_end": list(map(float, D.signals(ne.G, A, B, ne.pairs[(A, B)], ne.t_ref, T_END, K)))})
    out["dropped_attackers"] = sig
    return out


if __name__ == "__main__":
    with Pool(2) as p:
        res = p.map(one, range(101, 131))
    tot = {r: collections.Counter() for r in ROLES}
    for x in res:
        for r in ROLES: tot[r].update(x["roles"][r])
    N = sum(x["n"] for x in res)
    att = [r for r in ROLES[:2]]; ben = [r for r in ROLES[2:]]
    s = lambda roles, k: sum(tot[r][k] for r in roles)
    drop = [d for x in res for d in x["dropped_attackers"]]
    summary = {
        "accounts": N, "attackers": s(att, "n"),
        "attackers_flagged_endpoint": s(att, "endpoint_flagged"), "attackers_flagged_cumulative": s(att, "cumulative_flagged"),
        "attackers_never_flagged": s(att, "n") - s(att, "cumulative_flagged"),
        "attackers_unflagged_at_endpoint": s(att, "n") - s(att, "endpoint_flagged"),
        "attackers_high_endpoint": s(att, "endpoint_high"), "attackers_high_cumulative": s(att, "cumulative_high"),
        "benign_flagged_endpoint": s(ben, "endpoint_flagged"), "benign_flagged_cumulative": s(ben, "cumulative_flagged"),
        "benign_high_endpoint": s(ben, "endpoint_high"), "benign_high_cumulative": s(ben, "cumulative_high"),
        "benign_per_10k_endpoint": s(ben, "endpoint_flagged") / N * 1e4, "benign_per_10k_cumulative": s(ben, "cumulative_flagged") / N * 1e4,
        "by_role": {r: dict(tot[r]) for r in ROLES},
        "dropped_first_flag_hours": dict(collections.Counter(d["first_flag_h"] for d in drop)),
        "dropped_mean_signals": {"at_first_flag": dict(zip(NAMES, np.mean([d["at_first"] for d in drop], 0).round(3).tolist())),
                                 "at_end": dict(zip(NAMES, np.mean([d["at_end"] for d in drop], 0).round(3).tolist()))},
        "dropped_attackers": drop}
    json.dump(summary, open(os.path.join(HERE, "results", "cumulative_counts.json"), "w"), indent=1)
    print(json.dumps({k: v for k, v in summary.items() if k != "dropped_attackers"}, indent=1))
